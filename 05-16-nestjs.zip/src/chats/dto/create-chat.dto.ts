export class CreateChatDto {
  readonly chatID: string;
  readonly description: string;
}